package cs3500.three.trios.player;

/**
 * A type describing the type of player.
 */
public enum PlayerType {
  HUMAN, MAX_NUM_FLIPS, CORNER_MOVE
}
