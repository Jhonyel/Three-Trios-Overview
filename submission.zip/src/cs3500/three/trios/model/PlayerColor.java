package cs3500.three.trios.model;

/**
 * An enum class to represent the players in the game.
 */
public enum PlayerColor {
  RED, BLUE
}
